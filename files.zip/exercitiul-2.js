function isValid(s) {
  const stack = [];
  const pairs = { ")": "(", "]": "[", "}": "{" };

  for (const c of s) {
    if (c in pairs) {
      if (stack.pop() !== pairs[c]) {
        return false;
      }
    } else {
      stack.push(c);
    }
  }

  return stack.length === 0;
}

const tests = [
  { s: "()", expected: true },
  { s: "()[]{}", expected: true },
  { s: "(]", expected: false },
  { s: "([])", expected: true },
  { s: "([)]", expected: false },
];

tests.forEach(({ s, expected }, i) => {
  const output = isValid(s);
  console.log(
    `Example ${i + 1}: s="${s}" output=${output} expected=${expected} ${output === expected ? "PASS" : "FAIL"}`
  );
});

module.exports = isValid;
