class ListNode {
  constructor(val, next = null) {
    this.val = val;
    this.next = next;
  }
}

function reverseList(head) {
  let prev = null;
  let curr = head;

  while (curr !== null) {
    const next = curr.next;
    curr.next = prev;
    prev = curr;
    curr = next;
  }

  return prev;
}

function buildList(values) {
  let head = null;
  for (let i = values.length - 1; i >= 0; i--) {
    head = new ListNode(values[i], head);
  }
  return head;
}

function toArray(head) {
  const result = [];
  while (head !== null) {
    result.push(head.val);
    head = head.next;
  }
  return result;
}

const tests = [
  { input: [1, 2, 3, 4, 5], expected: [5, 4, 3, 2, 1] },
  { input: [1, 2], expected: [2, 1] },
  { input: [], expected: [] },
];

tests.forEach(({ input, expected }, i) => {
  const output = toArray(reverseList(buildList(input)));
  const passed = JSON.stringify(output) === JSON.stringify(expected);
  console.log(
    `Example ${i + 1}: input=[${input}] output=[${output}] expected=[${expected}] ${passed ? "PASS" : "FAIL"}`
  );
});

module.exports = reverseList;
