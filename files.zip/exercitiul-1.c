#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

typedef struct Node {
    int value;
    struct Node *next;
} Node;

typedef struct {
    Node *top;
} Stack;

typedef struct {
    Node *head;
    Node *tail;
} Queue;

static Node *node_create(int value) {
    Node *node = malloc(sizeof(Node));
    if (node == NULL) {
        fprintf(stderr, "Eroare: memorie insuficienta\n");
        return NULL;
    }
    node->value = value;
    node->next = NULL;
    return node;
}

void stack_init(Stack *stack) {
    stack->top = NULL;
}

bool stack_is_empty(const Stack *stack) {
    return stack->top == NULL;
}

bool stack_push(Stack *stack, int value) {
    Node *node = node_create(value);
    if (node == NULL) {
        return false;
    }
    node->next = stack->top;
    stack->top = node;
    return true;
}

bool stack_pop(Stack *stack, int *out) {
    if (stack_is_empty(stack)) {
        fprintf(stderr, "Eroare: pop pe un stack gol\n");
        return false;
    }
    Node *removed = stack->top;
    *out = removed->value;
    stack->top = removed->next;
    free(removed);
    return true;
}

bool stack_peek(const Stack *stack, int *out) {
    if (stack_is_empty(stack)) {
        fprintf(stderr, "Eroare: peek pe un stack gol\n");
        return false;
    }
    *out = stack->top->value;
    return true;
}

void stack_free(Stack *stack) {
    while (stack->top != NULL) {
        Node *next = stack->top->next;
        free(stack->top);
        stack->top = next;
    }
}

void queue_init(Queue *queue) {
    queue->head = NULL;
    queue->tail = NULL;
}

bool queue_is_empty(const Queue *queue) {
    return queue->head == NULL;
}

bool queue_enqueue(Queue *queue, int value) {
    Node *node = node_create(value);
    if (node == NULL) {
        return false;
    }
    if (queue->tail == NULL) {
        queue->head = node;
    } else {
        queue->tail->next = node;
    }
    queue->tail = node;
    return true;
}

bool queue_dequeue(Queue *queue, int *out) {
    if (queue_is_empty(queue)) {
        fprintf(stderr, "Eroare: dequeue pe o coada goala\n");
        return false;
    }
    Node *removed = queue->head;
    *out = removed->value;
    queue->head = removed->next;
    if (queue->head == NULL) {
        queue->tail = NULL;
    }
    free(removed);
    return true;
}

bool queue_front(const Queue *queue, int *out) {
    if (queue_is_empty(queue)) {
        fprintf(stderr, "Eroare: front pe o coada goala\n");
        return false;
    }
    *out = queue->head->value;
    return true;
}

void queue_free(Queue *queue) {
    while (queue->head != NULL) {
        Node *next = queue->head->next;
        free(queue->head);
        queue->head = next;
    }
    queue->tail = NULL;
}

static int passed = 0;
static int failed = 0;

static void check(bool condition, const char *description) {
    if (condition) {
        passed++;
        printf("PASS: %s\n", description);
    } else {
        failed++;
        printf("FAIL: %s\n", description);
    }
}

static void test_stack(void) {
    Stack stack;
    int value;
    stack_init(&stack);

    printf("\n--- Stack gol ---\n");
    check(stack_is_empty(&stack), "stack nou este gol");
    check(!stack_pop(&stack, &value), "pop pe stack gol esueaza");
    check(!stack_peek(&stack, &value), "peek pe stack gol esueaza");

    printf("\n--- Stack cu o valoare ---\n");
    stack_push(&stack, 5);
    check(!stack_is_empty(&stack), "stack nu este gol dupa push");
    check(stack_peek(&stack, &value) && value == 5, "peek returneaza 5");
    check(stack_pop(&stack, &value) && value == 5, "pop returneaza 5");
    check(stack_is_empty(&stack), "stack este gol dupa pop");

    printf("\n--- Stack cu mai multe valori (4, 7, 2) ---\n");
    stack_push(&stack, 4);
    stack_push(&stack, 7);
    stack_push(&stack, 2);
    check(stack_peek(&stack, &value) && value == 2, "peek returneaza 2");
    check(stack_pop(&stack, &value) && value == 2, "primul pop returneaza 2");
    check(stack_pop(&stack, &value) && value == 7, "al doilea pop returneaza 7");
    check(stack_pop(&stack, &value) && value == 4, "al treilea pop returneaza 4");
    check(stack_is_empty(&stack), "stack este gol dupa eliminarea tuturor valorilor");
    check(!stack_pop(&stack, &value), "pop dupa golire esueaza");

    printf("\n--- Stack: adaugare dupa golire ---\n");
    stack_push(&stack, 9);
    check(stack_peek(&stack, &value) && value == 9, "peek returneaza 9 dupa re-adaugare");
    stack_push(&stack, 10);
    stack_push(&stack, 11);

    stack_free(&stack);
    check(stack_is_empty(&stack), "stack este gol dupa stack_free");
}

static void test_queue(void) {
    Queue queue;
    int value;
    queue_init(&queue);

    printf("\n--- Queue gol ---\n");
    check(queue_is_empty(&queue), "queue nou este gol");
    check(!queue_dequeue(&queue, &value), "dequeue pe queue gol esueaza");
    check(!queue_front(&queue, &value), "front pe queue gol esueaza");

    printf("\n--- Queue cu o valoare ---\n");
    queue_enqueue(&queue, 5);
    check(!queue_is_empty(&queue), "queue nu este gol dupa enqueue");
    check(queue_front(&queue, &value) && value == 5, "front returneaza 5");
    check(queue_dequeue(&queue, &value) && value == 5, "dequeue returneaza 5");
    check(queue_is_empty(&queue), "queue este gol dupa dequeue");

    printf("\n--- Queue cu mai multe valori (4, 7, 2) ---\n");
    queue_enqueue(&queue, 4);
    queue_enqueue(&queue, 7);
    queue_enqueue(&queue, 2);
    check(queue_front(&queue, &value) && value == 4, "front returneaza 4");
    check(queue_dequeue(&queue, &value) && value == 4, "primul dequeue returneaza 4");
    check(queue_dequeue(&queue, &value) && value == 7, "al doilea dequeue returneaza 7");
    check(queue_dequeue(&queue, &value) && value == 2, "al treilea dequeue returneaza 2");
    check(queue_is_empty(&queue), "queue este gol dupa eliminarea tuturor valorilor");
    check(!queue_dequeue(&queue, &value), "dequeue dupa golire esueaza");

    printf("\n--- Queue: adaugare dupa golire ---\n");
    queue_enqueue(&queue, 9);
    check(queue_front(&queue, &value) && value == 9, "front returneaza 9 dupa re-adaugare");
    check(queue_dequeue(&queue, &value) && value == 9, "dequeue returneaza 9 dupa re-adaugare");
    queue_enqueue(&queue, 10);
    queue_enqueue(&queue, 11);

    queue_free(&queue);
    check(queue_is_empty(&queue), "queue este gol dupa queue_free");
}

int main(void) {
    test_stack();
    test_queue();
    printf("\nRezultat: %d trecute, %d esuate\n", passed, failed);
    return failed == 0 ? 0 : 1;
}
