class ListNode {
  constructor(val, next = null) {
    this.val = val;
    this.next = next;
  }
}

function getIntersectionNode(headA, headB) {
  let a = headA;
  let b = headB;

  while (a !== b) {
    a = a === null ? headB : a.next;
    b = b === null ? headA : b.next;
  }

  return a;
}

function buildList(values, tail = null) {
  let head = tail;
  for (let i = values.length - 1; i >= 0; i--) {
    head = new ListNode(values[i], head);
  }
  return head;
}

const tests = [
  { a: [4, 1], b: [5, 6, 1], shared: [8, 4, 5], expected: 8 },
  { a: [1, 9, 1], b: [3], shared: [2, 4], expected: 2 },
  { a: [2, 6, 4], b: [1, 5], shared: [], expected: null },
];

tests.forEach(({ a, b, shared, expected }, i) => {
  const common = buildList(shared);
  const headA = buildList(a, common);
  const headB = buildList(b, common);
  const node = getIntersectionNode(headA, headB);
  const output = node === null ? null : node.val;
  console.log(
    `Example ${i + 1}: output=${output} expected=${expected} ${node === common && output === expected ? "PASS" : "FAIL"}`
  );
});

module.exports = getIntersectionNode;
