from algorithms.binary_search import binary_search


def check(condition, description):
    print(f"{'PASS' if condition else 'FAIL'}: {description}")


if __name__ == "__main__":
    values = [-1, 0, 3, 5, 9, 12]

    tests = [
        (values, 9, 4, "target gasit (9)"),
        (values, 2, -1, "target lipsa intre valori (2)"),
        (values, -1, 0, "potrivire la primul index"),
        (values, 12, 5, "potrivire la ultimul index"),
        ([7], 7, 0, "o valoare, gasita"),
        ([7], 3, -1, "o valoare, lipsa"),
        (values, -5, -1, "target lipsa sub toate valorile"),
        (values, 20, -1, "target lipsa peste toate valorile"),
        ([], 1, -1, "array gol"),
    ]

    for nums, target, expected, name in tests:
        result = binary_search(nums, target)
        check(result == expected, f"{name}: nums={nums} target={target} -> {result}")
