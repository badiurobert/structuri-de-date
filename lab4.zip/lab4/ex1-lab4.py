from collections import Counter

from algorithms.quicksort import partition, quicksort
from algorithms.merge_sort import merge_sort


def check(condition, description):
    print(f"{'PASS' if condition else 'FAIL'}: {description}")


def partition_is_valid(values, lo, hi, p):
    pivot = values[p]
    left_ok = all(values[i] < pivot for i in range(lo, p))
    right_ok = all(values[i] >= pivot for i in range(p + 1, hi))
    return left_ok and right_ok


def test_first_partition():
    values = [6, 2, 5, 2, 1]
    p = partition(values, 0, len(values))
    check(values == [1, 2, 5, 2, 6] and p == 4, "prima partitie [6,2,5,2,1] -> [1,2,5,2,6], p = 4")
    check(partition_is_valid(values, 0, len(values), p), "stanga < pivot, dreapta >= pivot")


def test_sorting():
    tests = [
        ("exemplul din curs", [6, 2, 5, 2, 1]),
        ("array gol", []),
        ("o valoare", [42]),
        ("valori negative", [3, -1, -7, 0, 5, -2]),
        ("duplicate", [5, 1, 5, 1, 5, 1, 3]),
        ("deja sortat", [1, 2, 3, 4, 5, 6]),
        ("sortat invers", [9, 7, 5, 3, 1, -1]),
        ("toate egale", [4, 4, 4, 4, 4]),
    ]

    for name, original in tests:
        quick = list(original)
        merged = list(original)
        quicksort(quick)
        merge_sort(merged)

        expected = sorted(original)
        same_counts = Counter(quick) == Counter(original)
        check(quick == expected and same_counts, f"quicksort ({name}): {original} -> {quick}")
        check(quick == merged, f"quicksort == merge sort ({name})")


def test_comparisons():
    for values, expected in [([1, 2, 3, 4, 5], 10), ([2, 2, 2, 2, 2], 10)]:
        stats = {"comparisons": 0}
        copy = list(values)
        quicksort(copy, stats=stats)
        check(stats["comparisons"] == expected, f"comparatii cu pivotul pentru {values}: {stats['comparisons']}")


if __name__ == "__main__":
    test_first_partition()
    test_sorting()
    test_comparisons()
