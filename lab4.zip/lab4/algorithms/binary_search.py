def binary_search(values, target):
    lo = 0
    hi = len(values)

    while lo < hi:
        mid = lo + (hi - lo) // 2
        if values[mid] == target:
            return mid
        if values[mid] < target:
            lo = mid + 1
        else:
            hi = mid

    return -1


def search_insert(values, target):
    lo = 0
    hi = len(values)

    while lo < hi:
        mid = lo + (hi - lo) // 2
        if values[mid] < target:
            lo = mid + 1
        else:
            hi = mid

    return lo
