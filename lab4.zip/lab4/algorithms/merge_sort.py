def merge_sort(values):
    buffer = [0] * len(values)
    _sort(values, 0, len(values) - 1, buffer)


def _sort(values, left, right, buffer):
    if left >= right:
        return

    mid = (left + right) // 2
    _sort(values, left, mid, buffer)
    _sort(values, mid + 1, right, buffer)
    _merge(values, left, mid, right, buffer)


def _merge(values, left, mid, right, buffer):
    i = left
    j = mid + 1
    k = left

    while i <= mid and j <= right:
        if values[i] <= values[j]:
            buffer[k] = values[i]
            i += 1
        else:
            buffer[k] = values[j]
            j += 1
        k += 1

    while i <= mid:
        buffer[k] = values[i]
        i += 1
        k += 1

    while j <= right:
        buffer[k] = values[j]
        j += 1
        k += 1

    for t in range(left, right + 1):
        values[t] = buffer[t]
