def partition(values, lo, hi, stats=None):
    pivot = values[lo]
    boundary = lo

    for scan in range(lo + 1, hi):
        if stats is not None:
            stats["comparisons"] += 1
        if values[scan] < pivot:
            boundary += 1
            values[boundary], values[scan] = values[scan], values[boundary]

    values[lo], values[boundary] = values[boundary], values[lo]
    return boundary


def quicksort(values, lo=0, hi=None, stats=None):
    if hi is None:
        hi = len(values)

    if hi - lo <= 1:
        return

    p = partition(values, lo, hi, stats)
    quicksort(values, lo, p, stats)
    quicksort(values, p + 1, hi, stats)
