from algorithms.binary_search import search_insert


def check(condition, description):
    print(f"{'PASS' if condition else 'FAIL'}: {description}")


if __name__ == "__main__":
    values = [1, 3, 5, 6]

    tests = [
        (values, 5, 2, "target existent"),
        (values, 2, 1, "target lipsa intre valori"),
        (values, 0, 0, "target sub toate valorile"),
        (values, 7, 4, "target peste toate valorile"),
        ([4], 4, 0, "o valoare, egala"),
        ([4], 2, 0, "o valoare, target mai mic"),
        ([4], 9, 1, "o valoare, target mai mare"),
        ([], 3, 0, "array gol"),
    ]

    for nums, target, expected, name in tests:
        result = search_insert(nums, target)
        check(result == expected, f"{name}: nums={nums} target={target} -> {result}")
